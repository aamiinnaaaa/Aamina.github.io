ART & WORDS — Pinterest-style art website

1. Keep the "index.html" file and the "images" folder together.
2. Open index.html in a browser to view the website.
3. Replace images/art1.jpg ... art6.jpg with your own images (keep the names).
4. Open index.html again to see your updated gallery.

The site includes a search bar, category filters, responsive Pinterest-style columns, and save buttons.
